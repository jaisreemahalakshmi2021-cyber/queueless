# QueueLess — Smart Virtual Queue Management System

QueueLess lets customers join a service queue (hospital, bank, college office, salon, etc.)
from their phone instead of standing in a physical line. They see their live position,
a smart estimated wait time, and get updated automatically the moment the queue moves.
Organizations get a dashboard to manage services and call customers forward; a super
admin can oversee every organization on the platform.

Built solo as a college lab mini-project.

## Why this tech stack

| Layer | Choice | Why |
|---|---|---|
| Backend | Node.js + Express | Industry-standard, minimal boilerplate, huge community support |
| Database | **Node's built-in `node:sqlite`** (not an npm package) | Zero native/binary dependency — nothing to compile, nothing that can fail a Windows `npm install` right before a demo. Requires Node.js **22.5+**. |
| Real-time updates | Server-Sent Events (SSE), built into HTTP | Queue updates only ever flow server → browser, so a full WebSocket library (Socket.IO) isn't needed. One less dependency, and it's plain HTTP. |
| Auth | JWT (`jsonwebtoken`) + `bcryptjs` password hashing | Standard, stateless authentication |
| QR codes | Generated **in the browser** via a CDN QR library | No server-side image generation code needed; works the instant the page loads |
| Frontend | Plain HTML/CSS/JS + Tailwind (CDN) | No build step, no bundler — every page can be opened, read, and screenshotted directly |

Only 4 npm packages are needed (`express`, `cors`, `bcryptjs`, `jsonwebtoken`) and all four
are pure JavaScript — no native compilation step, so `npm install` should never fail because
of a missing C++ compiler.

## Requirements

- **Node.js 22.5 or later** (for the built-in `node:sqlite` module). Check with:
  ```
  node -v
  ```
  If it's older than v22.5, install the current LTS from https://nodejs.org.

## Getting started

```bash
npm install        # installs express, cors, bcryptjs, jsonwebtoken
npm run seed        # creates demo organizations, services, and a super admin
npm start           # starts the server on http://localhost:4000
```

Then open **http://localhost:4000** in your browser.

### Demo logins (created by `npm run seed`, password `password123` for all)

| Role | Email |
|---|---|
| Super admin | `superadmin@queueless.demo` |
| Org admin — City Clinic | `admin@cityclinic.demo` |
| Org admin — Sunrise Bank | `admin@sunrisebank.demo` |
| Org admin — Glow Salon | `admin@glowsalon.demo` |

Customers don't need seeding — just click **Sign up** and register with any email.

### Running the automated checks

```bash
npm test
```

This runs three dependency-free test files:
- `backend/utils/dateKey.test.js` — date/time helpers
- `backend/utils/waitEstimator.test.js` — the wait-time estimation algorithm (7 cases)
- `backend/models/integration.test.js` — the full queue engine against a real (throwaway)
  SQLite database: joining, ordering, calling next, auto-completing, cancelling, skipping,
  per-service daily token numbering, and organization suspension (10 cases)

There's also `scripts/smoke-test.sh`, an end-to-end HTTP test you can run against the live
server (`npm start` in one terminal, then `bash scripts/smoke-test.sh` in another) — it logs
in, joins a queue as a guest, checks the estimate, and calls next, printing each response.

## How the "smart" wait-time estimate works

See `backend/utils/waitEstimator.js`. Instead of just saying "you are #6", QueueLess:

1. Takes the organization's configured average service time (e.g. 7 min) as a baseline.
2. Once at least 3 customers have actually been served today, it computes a **real
   historical average** from their actual durations and blends it with the baseline
   (70% historical / 30% configured) — so the estimate self-corrects to how the service
   is actually running today, not just what the admin guessed it would be.
3. If someone is currently being served, it doesn't double-count their full average
   duration — it only adds however much of that average is *probably left*, based on
   how long they've already been in service.

## Feature summary (maps to the lab report's functional requirements)

**Customer:** register/login, browse organizations & services, join a queue (or scan a QR
code and join as a guest with no account), see live position + estimated wait, get
instant updates when the queue moves (via SSE — no page refresh needed), cancel a token,
view queue history.

**Organization (org_admin):** register an organization, create services and set their
average service time, open/close a queue, generate a QR-code join link + a public live
queue screen for a TV/monitor, call the next customer, skip or complete a customer, view
today's stats (waiting/serving/completed counts, average actual service time).

**Super admin:** view system-wide stats, list every organization and user, suspend or
reinstate an organization.

## Project structure

```
backend/
  server.js              Express app entry point
  db/
    connection.js         node:sqlite connection + transaction helper
    schema.js              CREATE TABLE statements
    seed.js                 demo data
  models/                  one file per table — all SQL lives here
  middleware/auth.js       JWT signing/verification, role guards
  routes/                  one file per resource (auth, organizations, services, tokens, admin)
  utils/
    waitEstimator.js        the smart wait-time algorithm (pure function, unit tested)
    dateKey.js               date helpers (daily token reset, elapsed-time calc)
    sseHub.js                 real-time broadcast hub (Server-Sent Events)
public/                    plain HTML/CSS/JS frontend (no build step)
scripts/smoke-test.sh      end-to-end curl-based smoke test
```

## Known limitations / possible future work

(Good material for the report's Feasibility Study / Future Enhancements sections.)

- Single-server, in-memory SSE hub — real-time updates work great for one server instance;
  a production deployment across multiple servers would need a shared pub/sub layer (e.g. Redis).
- No SMS/push notifications yet — "your turn is approaching" is currently shown only while
  the tracking page is open; a real deployment would add push notifications or SMS via a
  provider like Twilio.
- No password-reset flow.
- A token left "waiting" from a previous day (e.g. the organization never called it) is
  not automatically expired at midnight.

## License / academic note

Written for a solo college lab assignment (PSG Institute of Advanced Studies, Dept. of
CSE). Feel free to adapt freely for your own submission and resume.
