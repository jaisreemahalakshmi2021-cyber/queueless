/**
 * Renders the shared top navigation bar into <div id="nav"></div>,
 * adapting links to whether someone is logged out, a customer, an
 * org_admin, or a super_admin.
 */
function renderNav(activePage = "") {
  const mount = document.getElementById("nav");
  if (!mount) return;
  const user = Api.getUser();

  const linkClass = (page) =>
    "px-3 py-2 rounded-md text-sm font-medium " +
    (page === activePage ? "bg-indigo-600 text-white" : "text-slate-600 hover:bg-slate-100");

  let rightLinks = "";
  if (!user) {
    rightLinks = `
      <a href="login.html" class="${linkClass("login")}">Log in</a>
      <a href="register.html" class="${linkClass("register")}">Sign up</a>
    `;
  } else {
    if (user.role === "customer") {
      rightLinks += `<a href="dashboard-customer.html" class="${linkClass("dashboard-customer")}">My Queues</a>`;
    } else if (user.role === "org_admin") {
      rightLinks += `<a href="dashboard-org.html" class="${linkClass("dashboard-org")}">Org Dashboard</a>`;
    } else if (user.role === "super_admin") {
      rightLinks += `<a href="dashboard-admin.html" class="${linkClass("dashboard-admin")}">Admin Dashboard</a>`;
    }
    rightLinks += `
      <span class="text-sm text-slate-500 ml-2 hidden sm:inline">Hi, ${escapeHtml(user.name)}</span>
      <button id="nav-logout" class="px-3 py-2 rounded-md text-sm font-medium text-red-600 hover:bg-red-50">Log out</button>
    `;
  }

  mount.innerHTML = `
    <nav class="bg-white border-b border-slate-200">
      <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <a href="index.html" class="flex items-center gap-2 font-bold text-lg text-indigo-700">
          <span>🔷</span> QueueLess
        </a>
        <div class="flex items-center gap-1">
          <a href="index.html" class="${linkClass("index")}">Find a Queue</a>
          ${rightLinks}
        </div>
      </div>
    </nav>
  `;

  const logoutBtn = document.getElementById("nav-logout");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      Api.clearSession();
      window.location.href = "index.html";
    });
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
