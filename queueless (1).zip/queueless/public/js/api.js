/**
 * Small fetch wrapper shared by every page: attaches the JWT (if the
 * visitor is logged in), parses JSON, and throws a readable error message
 * on failure so pages can just show `err.message` to the user.
 */
const Api = (() => {
  function authHeader() {
    const token = localStorage.getItem("queueless_token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  async function request(method, path, body) {
    const res = await fetch(path, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...authHeader(),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_e) {
      // no JSON body (e.g. 204) — that's fine
    }
    if (!res.ok) {
      throw new Error((data && data.error) || `Request failed (${res.status})`);
    }
    return data;
  }

  return {
    get: (path) => request("GET", path),
    post: (path, body) => request("POST", path, body),
    patch: (path, body) => request("PATCH", path, body),

    getToken() {
      return localStorage.getItem("queueless_token");
    },
    getUser() {
      const raw = localStorage.getItem("queueless_user");
      return raw ? JSON.parse(raw) : null;
    },
    setSession(token, user) {
      localStorage.setItem("queueless_token", token);
      localStorage.setItem("queueless_user", JSON.stringify(user));
    },
    clearSession() {
      localStorage.removeItem("queueless_token");
      localStorage.removeItem("queueless_user");
    },
    isLoggedIn() {
      return Boolean(localStorage.getItem("queueless_token"));
    },
  };
})();
