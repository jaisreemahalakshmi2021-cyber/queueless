/**
 * Raw CREATE TABLE / CREATE INDEX statements, kept in their own dependency-free
 * module (no `require("./connection")` here) so `connection.js` can run them
 * immediately after opening the database — before any model file gets a
 * chance to `db.prepare()` a query against a table that doesn't exist yet.
 */
const SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('customer', 'org_admin', 'super_admin')),
    organization_id INTEGER REFERENCES organizations(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    description TEXT DEFAULT '',
    is_suspended INTEGER NOT NULL DEFAULT 0,
    created_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    organization_id INTEGER NOT NULL REFERENCES organizations(id),
    name TEXT NOT NULL,
    avg_service_time_minutes REAL NOT NULL DEFAULT 7,
    is_open INTEGER NOT NULL DEFAULT 1,
    last_token_date TEXT,
    last_token_number INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_id INTEGER NOT NULL REFERENCES services(id),
    user_id INTEGER REFERENCES users(id),
    guest_name TEXT,
    token_number INTEGER NOT NULL,
    token_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'serving', 'completed', 'skipped', 'cancelled')),
    joined_at TEXT NOT NULL DEFAULT (datetime('now')),
    called_at TEXT,
    completed_at TEXT,
    actual_duration_minutes REAL
  );

  CREATE INDEX IF NOT EXISTS idx_tokens_service_status ON tokens(service_id, status);
  CREATE INDEX IF NOT EXISTS idx_tokens_service_date ON tokens(service_id, token_date);
  CREATE INDEX IF NOT EXISTS idx_services_org ON services(organization_id);
`;

module.exports = { SCHEMA_SQL };
