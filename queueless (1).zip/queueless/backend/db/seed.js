/**
 * Seeds the database with demo data so the app is immediately usable for
 * a lab demo/screenshot session: one super admin, a few organizations
 * (each with an org_admin login) and services. Safe to re-run — it skips
 * anything that already exists instead of creating duplicates.
 *
 * Usage: npm run seed
 */
const bcrypt = require("bcryptjs");
const { initSchema } = require("./schema");
const User = require("../models/User");
const Organization = require("../models/Organization");
const Service = require("../models/Service");

initSchema();

function ensureUser({ name, email, password, role }) {
  const existing = User.getByEmail(email);
  if (existing) return existing;
  return User.create({ name, email, passwordHash: bcrypt.hashSync(password, 10), role });
}

const DEMO_ACCOUNTS_PASSWORD = "password123";

// 1. Super admin
ensureUser({
  name: "System Administrator",
  email: "superadmin@queueless.demo",
  password: DEMO_ACCOUNTS_PASSWORD,
  role: "super_admin",
});

// 2. Demo organizations, each with its own admin login and a couple of services
const demoOrgs = [
  {
    orgName: "City Clinic",
    category: "hospital",
    adminEmail: "admin@cityclinic.demo",
    services: [
      { name: "General Consultation", avgServiceTimeMinutes: 7 },
      { name: "Vaccination", avgServiceTimeMinutes: 4 },
    ],
  },
  {
    orgName: "Sunrise Bank",
    category: "bank",
    adminEmail: "admin@sunrisebank.demo",
    services: [
      { name: "Cash Deposit / Withdrawal", avgServiceTimeMinutes: 5 },
      { name: "New Account Opening", avgServiceTimeMinutes: 15 },
    ],
  },
  {
    orgName: "Glow Salon",
    category: "salon",
    adminEmail: "admin@glowsalon.demo",
    services: [{ name: "Haircut", avgServiceTimeMinutes: 20 }],
  },
];

for (const orgDef of demoOrgs) {
  let admin = User.getByEmail(orgDef.adminEmail);
  let org;
  if (admin && admin.organization_id) {
    org = Organization.getById(admin.organization_id);
  } else {
    admin = ensureUser({
      name: `${orgDef.orgName} Admin`,
      email: orgDef.adminEmail,
      password: DEMO_ACCOUNTS_PASSWORD,
      role: "org_admin",
    });
    org = Organization.create({ name: orgDef.orgName, category: orgDef.category, createdBy: admin.id });
    User.attachOrganization(admin.id, org.id);
  }

  const existingServices = Service.listByOrganization(org.id);
  if (existingServices.length === 0) {
    for (const svc of orgDef.services) {
      Service.create({ organizationId: org.id, name: svc.name, avgServiceTimeMinutes: svc.avgServiceTimeMinutes });
    }
  }
}

console.log("Seed complete. Demo logins (password for all: 'password123'):");
console.log("  Super admin :  superadmin@queueless.demo");
for (const orgDef of demoOrgs) {
  console.log(`  ${orgDef.orgName.padEnd(14)}:  ${orgDef.adminEmail}`);
}
console.log("\nCustomers: just register a new account from the app (any email/password).");
