const db = require("./connection");
const { SCHEMA_SQL } = require("./schemaSql");

/**
 * Creates all tables if they don't already exist. `connection.js` already
 * runs this SQL the moment the database is opened (see the comment there),
 * so calling this explicitly is redundant but harmless — CREATE TABLE IF
 * NOT EXISTS is idempotent. Kept around so existing call sites and tests
 * that call `initSchema()` explicitly keep working.
 */
function initSchema() {
  db.exec(SCHEMA_SQL);
}

module.exports = { initSchema };
