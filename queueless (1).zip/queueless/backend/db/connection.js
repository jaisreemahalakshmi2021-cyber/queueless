const path = require("path");
const { DatabaseSync } = require("node:sqlite");
const { SCHEMA_SQL } = require("./schemaSql");

/**
 * QueueLess deliberately uses Node's own built-in SQLite module
 * (node:sqlite, stable since Node 22) instead of an npm database driver.
 * It needs Node.js 22.5+ — see the README for how to check/upgrade.
 *
 * Why: a third-party native SQLite binding (e.g. better-sqlite3) has to
 * download a prebuilt binary (or compile one) for your exact OS/CPU
 * during `npm install`, which is the single most common way a student's
 * first `npm install` fails right before a demo. Using the driver that
 * ships inside Node itself removes that risk entirely — there is
 * nothing to compile and nothing extra to download.
 */
const DB_PATH = process.env.QUEUELESS_DB_PATH || path.join(__dirname, "queueless.db");
const db = new DatabaseSync(DB_PATH);

db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

// Create tables the moment the connection is opened — every model file
// requires this module before it prepares any statement, so this guarantees
// the tables already exist no matter what order files get required in
// elsewhere (server.js, seed.js, tests, ...). CREATE TABLE IF NOT EXISTS is
// idempotent, so this is safe to run every time the process starts.
db.exec(SCHEMA_SQL);

/**
 * node:sqlite's DatabaseSync has no built-in `.transaction()` helper (unlike
 * better-sqlite3), so this provides the same "wrap a function, run it
 * atomically" convenience used throughout the models.
 */
function transaction(fn) {
  return (...args) => {
    db.exec("BEGIN");
    try {
      const result = fn(...args);
      db.exec("COMMIT");
      return result;
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  };
}

module.exports = db;
module.exports.transaction = transaction;
