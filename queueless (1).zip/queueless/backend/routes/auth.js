const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const Organization = require("../models/Organization");
const { signToken, requireAuth } = require("../middleware/auth");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Register a new account.
 * - role "customer": just a normal account.
 * - role "org_admin": also creates the organization they'll manage
 *   (organizationName, organizationCategory required). Keeps the flow to
 *   one step for a solo student project; a super admin can still suspend
 *   any organization from the admin dashboard.
 */
router.post("/register", (req, res) => {
  const { name, email, password, role = "customer", organizationName, organizationCategory } = req.body || {};

  if (!name || !email || !password) {
    return res.status(400).json({ error: "name, email and password are required" });
  }
  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: "Please enter a valid email address" });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  }
  if (!["customer", "org_admin"].includes(role)) {
    return res.status(400).json({ error: "Invalid role for self-registration" });
  }
  if (role === "org_admin" && !organizationName) {
    return res.status(400).json({ error: "organizationName is required for an organization account" });
  }
  if (User.getByEmail(email)) {
    return res.status(409).json({ error: "An account with that email already exists" });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  let user = User.create({ name, email, passwordHash, role });

  if (role === "org_admin") {
    const org = Organization.create({
      name: organizationName,
      category: organizationCategory || "general",
      createdBy: user.id,
    });
    User.attachOrganization(user.id, org.id);
    user = User.getById(user.id);
  }

  const token = signToken(user);
  res.status(201).json({ token, user: User.toSafeJSON(user) });
});

router.post("/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required" });
  }
  const user = User.getByEmail(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Incorrect email or password" });
  }
  const token = signToken(user);
  res.json({ token, user: User.toSafeJSON(user) });
});

router.get("/me", requireAuth, (req, res) => {
  const user = User.getById(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user: User.toSafeJSON(user) });
});

module.exports = router;
