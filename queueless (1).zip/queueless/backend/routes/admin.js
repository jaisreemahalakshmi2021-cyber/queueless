const express = require("express");
const Organization = require("../models/Organization");
const User = require("../models/User");
const db = require("../db/connection");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth, requireRole("super_admin"));

router.get("/organizations", (req, res) => {
  res.json({ organizations: Organization.listForAdmin() });
});

router.patch("/organizations/:id/suspend", (req, res) => {
  const { suspended } = req.body || {};
  const org = Organization.getById(req.params.id);
  if (!org) return res.status(404).json({ error: "Organization not found" });
  const updated = Organization.setSuspendedStatus(org.id, Boolean(suspended));
  res.json({ organization: updated });
});

router.get("/users", (req, res) => {
  res.json({ users: User.list() });
});

/** System-wide numbers for the super admin dashboard. */
router.get("/stats", (req, res) => {
  const orgCount = db.prepare(`SELECT COUNT(*) AS c FROM organizations`).get().c;
  const activeOrgCount = db.prepare(`SELECT COUNT(*) AS c FROM organizations WHERE is_suspended = 0`).get().c;
  const serviceCount = db.prepare(`SELECT COUNT(*) AS c FROM services`).get().c;
  const userCount = db.prepare(`SELECT COUNT(*) AS c FROM users`).get().c;
  const tokensToday = db.prepare(`SELECT COUNT(*) AS c FROM tokens WHERE token_date = date('now')`).get().c;
  const completedToday = db
    .prepare(`SELECT COUNT(*) AS c FROM tokens WHERE token_date = date('now') AND status = 'completed'`)
    .get().c;

  res.json({
    organizations: orgCount,
    activeOrganizations: activeOrgCount,
    services: serviceCount,
    users: userCount,
    tokensToday,
    completedToday,
  });
});

module.exports = router;
