const express = require("express");
const Organization = require("../models/Organization");
const Service = require("../models/Service");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

/** Public: list active organizations customers can search/browse. */
router.get("/", (req, res) => {
  res.json({ organizations: Organization.listPublic() });
});

/** Public: services offered by one organization (for the customer to pick from). */
router.get("/:id/services", (req, res) => {
  const org = Organization.getById(req.params.id);
  if (!org || org.is_suspended) return res.status(404).json({ error: "Organization not found" });
  res.json({ organization: org, services: Service.listByOrganization(org.id) });
});

/** org_admin: create a new service under their own organization. */
router.post("/:id/services", requireAuth, requireRole("org_admin"), (req, res) => {
  const orgId = Number(req.params.id);
  if (req.user.organizationId !== orgId) {
    return res.status(403).json({ error: "You can only manage your own organization" });
  }
  const { name, avgServiceTimeMinutes } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });
  const avg = Number(avgServiceTimeMinutes) || 7;
  if (avg <= 0) return res.status(400).json({ error: "avgServiceTimeMinutes must be positive" });
  const service = Service.create({ organizationId: orgId, name, avgServiceTimeMinutes: avg });
  res.status(201).json({ service });
});

module.exports = router;
