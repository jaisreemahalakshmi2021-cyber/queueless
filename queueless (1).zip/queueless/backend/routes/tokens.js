const express = require("express");
const Token = require("../models/Token");
const Service = require("../models/Service");
const { requireAuth, requireRole } = require("../middleware/auth");
const { broadcast } = require("../utils/sseHub");
const { minutesSince } = require("../utils/dateKey");
const { estimateWait } = require("../utils/waitEstimator");

const router = express.Router();

/** Builds the full "position + estimated wait" view for a token. */
function buildTokenView(token) {
  const service = Service.getById(token.service_id);
  const serving = Token.getCurrentServing(token.service_id, token.token_date);
  const isMeServing = serving && serving.id === token.id;

  const peopleAhead = token.status === "waiting" ? Token.peopleAheadOf(token) : 0;
  const recentDurations = Token.getRecentDurations(token.service_id, 10);
  const currentServingElapsedMinutes = serving && !isMeServing && serving.called_at
    ? minutesSince(serving.called_at)
    : null;

  let estimate = null;
  if (token.status === "waiting") {
    estimate = estimateWait({
      peopleAhead,
      avgServiceTimeMinutes: service.avg_service_time_minutes,
      recentDurationsMinutes: recentDurations,
      currentServingElapsedMinutes,
    });
  }

  return {
    token,
    service,
    nowServingTokenNumber: serving ? serving.token_number : null,
    peopleAhead,
    estimatedWaitMinutes: estimate ? estimate.estimatedWaitMinutes : token.status === "serving" ? 0 : null,
  };
}

router.get("/history/me", requireAuth, requireRole("customer"), (req, res) => {
  res.json({ history: Token.historyFor(req.user.id) });
});

router.get("/:id", (req, res) => {
  const token = Token.getById(req.params.id);
  if (!token) return res.status(404).json({ error: "Token not found" });
  res.json(buildTokenView(token));
});

/** Owner (or a guest who kept the token id) cancels a still-waiting token. */
router.post("/:id/cancel", (req, res) => {
  const token = Token.getById(req.params.id);
  if (!token) return res.status(404).json({ error: "Token not found" });
  const cancelled = Token.cancel(token.id);
  if (!cancelled) return res.status(409).json({ error: "Only a token that is still waiting can be cancelled" });
  broadcast(token.service_id, "queue-update", { reason: "cancelled" });
  res.json({ token: cancelled });
});

router.post("/:id/complete", requireAuth, requireRole("org_admin"), (req, res) => {
  const token = Token.getById(req.params.id);
  if (!token) return res.status(404).json({ error: "Token not found" });
  const service = Service.getById(token.service_id);
  if (req.user.organizationId !== service.organization_id) {
    return res.status(403).json({ error: "You can only manage your own organization's queue" });
  }
  const completed = Token.completeCurrent(token.id);
  if (!completed) return res.status(409).json({ error: "Only a token currently being served can be completed" });
  broadcast(token.service_id, "queue-update", { reason: "completed" });
  res.json({ token: completed });
});

router.post("/:id/skip", requireAuth, requireRole("org_admin"), (req, res) => {
  const token = Token.getById(req.params.id);
  if (!token) return res.status(404).json({ error: "Token not found" });
  const service = Service.getById(token.service_id);
  if (req.user.organizationId !== service.organization_id) {
    return res.status(403).json({ error: "You can only manage your own organization's queue" });
  }
  const skipped = Token.skip(token.id);
  if (!skipped) return res.status(409).json({ error: "This token can no longer be skipped" });
  broadcast(token.service_id, "queue-update", { reason: "skipped" });
  res.json({ token: skipped });
});

module.exports = router;
