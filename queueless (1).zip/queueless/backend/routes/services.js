const express = require("express");
const Service = require("../models/Service");
const Token = require("../models/Token");
const { requireAuth, requireRole, optionalAuth } = require("../middleware/auth");
const { broadcast, subscribe } = require("../utils/sseHub");

const router = express.Router();

function assertOwnsService(req, res, service) {
  if (!service) {
    res.status(404).json({ error: "Service not found" });
    return false;
  }
  if (req.user.organizationId !== service.organization_id) {
    res.status(403).json({ error: "You can only manage services in your own organization" });
    return false;
  }
  return true;
}

/** Public: live snapshot for a service — now serving + next few in line. Powers the big-screen display. */
router.get("/:id/queue", (req, res) => {
  const service = Service.getById(req.params.id);
  if (!service) return res.status(404).json({ error: "Service not found" });
  const serving = Token.getCurrentServing(service.id);
  res.json({
    service,
    nowServing: serving ? serving.token_number : null,
    upcoming: Token.upcomingTokenNumbers(service.id, 5),
  });
});

/** Public: Server-Sent Events stream that fires whenever this service's queue changes. */
router.get("/:id/events", (req, res) => {
  subscribe(Number(req.params.id), res);
});

/** org_admin: update service settings (avg service time, open/closed). */
router.patch("/:id", requireAuth, requireRole("org_admin"), (req, res) => {
  const service = Service.getById(req.params.id);
  if (!assertOwnsService(req, res, service)) return;
  const { avgServiceTimeMinutes, isOpen } = req.body || {};
  if (avgServiceTimeMinutes !== undefined && Number(avgServiceTimeMinutes) <= 0) {
    return res.status(400).json({ error: "avgServiceTimeMinutes must be positive" });
  }
  const updated = Service.updateService(service.id, {
    avgServiceTimeMinutes: avgServiceTimeMinutes !== undefined ? Number(avgServiceTimeMinutes) : undefined,
    isOpen,
  });
  broadcast(service.id, "queue-update", { reason: "service-settings-changed" });
  res.json({ service: updated });
});

/** org_admin: today's full token list + stats for the dashboard table. */
router.get("/:id/stats", requireAuth, requireRole("org_admin"), (req, res) => {
  const service = Service.getById(req.params.id);
  if (!assertOwnsService(req, res, service)) return;
  const todayTokens = Token.listToday(service.id);
  const counts = { waiting: 0, serving: 0, completed: 0, skipped: 0, cancelled: 0 };
  for (const t of todayTokens) counts[t.status] = (counts[t.status] || 0) + 1;
  const recentDurations = Token.getRecentDurations(service.id, 10);
  const avgActual = recentDurations.length
    ? Math.round((recentDurations.reduce((a, b) => a + b, 0) / recentDurations.length) * 10) / 10
    : null;
  res.json({ service, tokens: todayTokens, counts, averageActualServiceMinutes: avgActual });
});

/** org_admin: call the next waiting customer (auto-completes whoever is currently serving). */
router.post("/:id/call-next", requireAuth, requireRole("org_admin"), (req, res) => {
  const service = Service.getById(req.params.id);
  if (!assertOwnsService(req, res, service)) return;
  const token = Token.callNext(service.id);
  broadcast(service.id, "queue-update", { reason: "called-next" });
  if (!token) return res.json({ token: null, message: "No one is waiting" });
  res.json({ token });
});

/** Anyone (customer or guest): join the virtual queue for a service. */
router.post("/:id/join", (req, res) => {
  // optional auth: logged-in customers get user_id attached, guests (QR scans) provide a name
  optionalAuth(req, res, () => {
    const service = Service.getById(req.params.id);
    if (!service) return res.status(404).json({ error: "Service not found" });
    if (!service.is_open) return res.status(409).json({ error: "This queue is currently closed" });

    const isLoggedInCustomer = req.user && req.user.role === "customer";
    const guestName = (req.body && req.body.guestName) || null;
    if (!isLoggedInCustomer && !guestName) {
      return res.status(400).json({ error: "guestName is required when not logged in" });
    }

    const token = Token.joinQueue({
      serviceId: service.id,
      userId: isLoggedInCustomer ? req.user.id : null,
      guestName: isLoggedInCustomer ? null : guestName,
    });
    broadcast(service.id, "queue-update", { reason: "joined" });
    res.status(201).json({ token });
  });
});

module.exports = router;
