const path = require("path");
const express = require("express");
const cors = require("cors");

const { initSchema } = require("./db/schema");
const authRoutes = require("./routes/auth");
const organizationRoutes = require("./routes/organizations");
const serviceRoutes = require("./routes/services");
const tokenRoutes = require("./routes/tokens");
const adminRoutes = require("./routes/admin");

initSchema();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/organizations", organizationRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/tokens", tokenRoutes);
app.use("/api/admin", adminRoutes);

app.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

// Serve the frontend (plain HTML/CSS/JS, no build step needed).
app.use(express.static(path.join(__dirname, "..", "public")));

// Fallback 404 for unknown API routes (kept after static so real pages still work).
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server" });
});

app.listen(PORT, () => {
  console.log(`\nQueueLess server running:  http://localhost:${PORT}`);
  console.log(`If you haven't yet, run:   npm run seed   (creates demo organizations & a super admin)\n`);
});
