/**
 * waitEstimator.js
 * ------------------------------------------------------------------
 * Pure, dependency-free module that implements QueueLess's "smart"
 * wait-time estimation. Kept dependency-free on purpose so it can be
 * unit-tested in isolation (see backend/utils/waitEstimator.test.js)
 * without needing the database, Express, or any npm package.
 *
 * Algorithm
 * ---------
 * 1. Blend the organization's configured average service time with the
 *    service's *actual* historical average (computed from recently
 *    completed tokens), weighted 30/70 in favour of real history once
 *    enough samples exist. This is what turns "you are #10" into a
 *    genuine estimate instead of a guess.
 * 2. If someone is currently being served, we already know how long
 *    they have been in service, so we don't double count their full
 *    average duration — we only count what's *left* of it.
 * 3. The result is clamped and rounded to a whole number of minutes
 *    that's friendly to display ("Estimated wait: 32 min").
 */

const MIN_SAMPLES_FOR_HISTORY = 3;
const HISTORY_WEIGHT = 0.7;
const CONFIGURED_WEIGHT = 0.3;
const MIN_REMAINING_FRACTION = 0.15; // a person "in service" always has at least this fraction of the average left

/**
 * @param {number[]} recentDurationsMinutes - actual service durations (minutes) of the most recently completed tokens for this service, newest first or any order.
 * @returns {number|null} historical average in minutes, or null if not enough data yet.
 */
function computeHistoricalAverage(recentDurationsMinutes) {
  if (!Array.isArray(recentDurationsMinutes) || recentDurationsMinutes.length < MIN_SAMPLES_FOR_HISTORY) {
    return null;
  }
  const sum = recentDurationsMinutes.reduce((a, b) => a + b, 0);
  return sum / recentDurationsMinutes.length;
}

/**
 * @param {object} params
 * @param {number} params.peopleAhead - number of tokens still WAITING ahead of this one (does not include the token currently being served, if any).
 * @param {number} params.avgServiceTimeMinutes - organization-configured baseline average service time for the service.
 * @param {number[]} [params.recentDurationsMinutes] - recent actual completed-service durations (minutes) for this service, used to compute a historical average.
 * @param {number|null} [params.currentServingElapsedMinutes] - minutes elapsed since the currently-serving token was called, or null/undefined if nobody is currently being served.
 * @returns {{ estimatedWaitMinutes: number, effectiveAvgMinutes: number, historicalAvgMinutes: number|null }}
 */
function estimateWait({
  peopleAhead,
  avgServiceTimeMinutes,
  recentDurationsMinutes = [],
  currentServingElapsedMinutes = null,
}) {
  if (typeof peopleAhead !== "number" || peopleAhead < 0) {
    throw new Error("peopleAhead must be a non-negative number");
  }
  if (typeof avgServiceTimeMinutes !== "number" || avgServiceTimeMinutes <= 0) {
    throw new Error("avgServiceTimeMinutes must be a positive number");
  }

  const historicalAvgMinutes = computeHistoricalAverage(recentDurationsMinutes);

  const effectiveAvgMinutes = historicalAvgMinutes !== null
    ? HISTORY_WEIGHT * historicalAvgMinutes + CONFIGURED_WEIGHT * avgServiceTimeMinutes
    : avgServiceTimeMinutes;

  let waitMinutes = peopleAhead * effectiveAvgMinutes;

  const isSomeoneBeingServed = currentServingElapsedMinutes !== null && currentServingElapsedMinutes !== undefined;
  if (isSomeoneBeingServed) {
    const minRemaining = effectiveAvgMinutes * MIN_REMAINING_FRACTION;
    const remainingForCurrent = Math.max(effectiveAvgMinutes - currentServingElapsedMinutes, minRemaining);
    // The person ahead-of-queue count already excludes whoever is being served,
    // so we add the *remaining* time for that person on top of the full
    // average for everyone else waiting.
    waitMinutes += remainingForCurrent;
  }

  return {
    estimatedWaitMinutes: Math.max(0, Math.round(waitMinutes)),
    effectiveAvgMinutes: Math.round(effectiveAvgMinutes * 10) / 10,
    historicalAvgMinutes: historicalAvgMinutes !== null ? Math.round(historicalAvgMinutes * 10) / 10 : null,
  };
}

module.exports = { estimateWait, computeHistoricalAverage, MIN_SAMPLES_FOR_HISTORY };
