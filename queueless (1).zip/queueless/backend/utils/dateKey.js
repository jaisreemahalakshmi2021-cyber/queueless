/**
 * Small date helper used to reset token numbers every day, the way a
 * real token-counter at a clinic or bank resets to #1 each morning.
 * Pure and dependency-free so it's trivially testable.
 */
function todayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/** SQLite's datetime('now') yields "YYYY-MM-DD HH:MM:SS" (UTC, no separator/zone). */
function parseSqliteUtc(sqliteDateTime) {
  return new Date(sqliteDateTime.replace(" ", "T") + "Z");
}

/** Minutes elapsed between now and a SQLite UTC datetime string. */
function minutesSince(sqliteDateTime) {
  return (Date.now() - parseSqliteUtc(sqliteDateTime).getTime()) / 60000;
}

module.exports = { todayKey, parseSqliteUtc, minutesSince };
