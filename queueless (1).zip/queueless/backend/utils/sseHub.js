/**
 * Minimal Server-Sent-Events hub for real-time queue updates.
 *
 * Why SSE instead of Socket.IO? QueueLess only ever needs to push data
 * from server -> browser (queue changed, call the next customer, etc).
 * SSE does exactly that over plain HTTP with zero extra dependencies —
 * one less native/binary package a student has to get installed correctly
 * before a demo. Every subscriber is just a kept-open HTTP response.
 */
const channels = new Map(); // serviceId (number) -> Set<res>

function subscribe(serviceId, res) {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "Access-Control-Allow-Origin": "*",
  });
  res.write("retry: 2000\n\n");

  if (!channels.has(serviceId)) channels.set(serviceId, new Set());
  channels.get(serviceId).add(res);

  const keepAlive = setInterval(() => {
    res.write(": keep-alive\n\n");
  }, 25000);

  res.on("close", () => {
    clearInterval(keepAlive);
    const set = channels.get(serviceId);
    if (set) {
      set.delete(res);
      if (set.size === 0) channels.delete(serviceId);
    }
  });
}

function broadcast(serviceId, eventName, payload) {
  const set = channels.get(serviceId);
  if (!set || set.size === 0) return;
  const message = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of set) {
    res.write(message);
  }
}

module.exports = { subscribe, broadcast };
