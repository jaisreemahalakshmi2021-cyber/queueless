const assert = require("node:assert");
const { todayKey, parseSqliteUtc, minutesSince } = require("./dateKey");

{
  const d = new Date(2026, 8, 14); // Sept is month index 8
  assert.strictEqual(todayKey(d), "2026-09-14");
  console.log("PASS: todayKey formats as YYYY-MM-DD");
}

{
  const parsed = parseSqliteUtc("2026-09-14 10:00:00");
  assert.strictEqual(parsed.toISOString(), "2026-09-14T10:00:00.000Z");
  console.log("PASS: parseSqliteUtc parses sqlite datetime as UTC");
}

{
  const fiveMinAgo = new Date(Date.now() - 5 * 60000);
  const sqliteStr = fiveMinAgo.toISOString().slice(0, 19).replace("T", " ");
  const mins = minutesSince(sqliteStr);
  assert.ok(mins > 4.9 && mins < 5.1, `expected ~5 minutes, got ${mins}`);
  console.log("PASS: minutesSince computes elapsed minutes");
}

console.log("\nAll dateKey tests passed.");
