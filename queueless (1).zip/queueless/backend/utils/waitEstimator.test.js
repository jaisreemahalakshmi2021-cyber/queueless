/**
 * Plain Node.js test (no test framework, no npm deps) for waitEstimator.
 * Run with: node backend/utils/waitEstimator.test.js
 */
const assert = require("node:assert");
const { estimateWait, computeHistoricalAverage } = require("./waitEstimator");

function approxEqual(a, b, tolerance, msg) {
  assert.ok(Math.abs(a - b) <= tolerance, `${msg} — expected ~${b}, got ${a}`);
}

// 1. No history yet -> falls back to configured average
{
  const r = estimateWait({ peopleAhead: 5, avgServiceTimeMinutes: 7 });
  assert.strictEqual(r.historicalAvgMinutes, null);
  assert.strictEqual(r.effectiveAvgMinutes, 7);
  assert.strictEqual(r.estimatedWaitMinutes, 35); // 5 * 7
  console.log("PASS: falls back to configured average with no history");
}

// 2. With enough history, blends 70% history / 30% configured
{
  const r = estimateWait({
    peopleAhead: 5,
    avgServiceTimeMinutes: 10,
    recentDurationsMinutes: [6, 6, 6, 6], // avg 6
  });
  approxEqual(r.historicalAvgMinutes, 6, 0.01, "historical avg");
  const expectedEffective = 0.7 * 6 + 0.3 * 10; // 7.2
  approxEqual(r.effectiveAvgMinutes, 7.2, 0.05, "effective avg blend");
  approxEqual(r.estimatedWaitMinutes, Math.round(5 * expectedEffective), 1, "blended wait");
  console.log("PASS: blends historical and configured averages");
}

// 3. Fewer than 3 samples -> not enough history, falls back
{
  const r = estimateWait({
    peopleAhead: 3,
    avgServiceTimeMinutes: 8,
    recentDurationsMinutes: [4, 5], // only 2 samples
  });
  assert.strictEqual(r.historicalAvgMinutes, null);
  assert.strictEqual(r.effectiveAvgMinutes, 8);
  console.log("PASS: ignores history when sample size is too small");
}

// 4. Someone currently being served reduces (not doubles) the wait
{
  const withoutServing = estimateWait({ peopleAhead: 2, avgServiceTimeMinutes: 10 });
  const withServingEarly = estimateWait({ peopleAhead: 2, avgServiceTimeMinutes: 10, currentServingElapsedMinutes: 1 });
  const withServingLate = estimateWait({ peopleAhead: 2, avgServiceTimeMinutes: 10, currentServingElapsedMinutes: 9 });
  assert.ok(withServingLate.estimatedWaitMinutes < withServingEarly.estimatedWaitMinutes,
    "the longer the current person has already been served, the shorter the remaining wait should be");
  assert.ok(withServingEarly.estimatedWaitMinutes > withoutServing.estimatedWaitMinutes,
    "a currently-serving person should add to the wait on top of peopleAhead");
  console.log("PASS: accounts for elapsed time of the currently-serving token");
}

// 5. Zero people ahead and nobody being served -> zero wait
{
  const r = estimateWait({ peopleAhead: 0, avgServiceTimeMinutes: 7 });
  assert.strictEqual(r.estimatedWaitMinutes, 0);
  console.log("PASS: zero wait when queue is empty");
}

// 6. computeHistoricalAverage edge cases
{
  assert.strictEqual(computeHistoricalAverage([]), null);
  assert.strictEqual(computeHistoricalAverage([5, 5]), null); // below MIN_SAMPLES_FOR_HISTORY
  assert.strictEqual(computeHistoricalAverage([4, 6, 5]), 5);
  console.log("PASS: computeHistoricalAverage edge cases");
}

// 7. Input validation
{
  assert.throws(() => estimateWait({ peopleAhead: -1, avgServiceTimeMinutes: 5 }));
  assert.throws(() => estimateWait({ peopleAhead: 1, avgServiceTimeMinutes: 0 }));
  console.log("PASS: validates inputs");
}

console.log("\nAll waitEstimator tests passed.");
