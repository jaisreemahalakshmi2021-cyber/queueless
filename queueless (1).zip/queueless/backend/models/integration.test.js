/**
 * Integration test for the model layer (schema + Organization + Service +
 * Token, working together through the real node:sqlite database) — no
 * Express, no HTTP, no third-party npm packages. Run against a throwaway
 * database file so it never touches real data:
 *
 *   QUEUELESS_DB_PATH=/tmp/queueless-test.db node backend/models/integration.test.js
 */
const assert = require("node:assert");
const fs = require("node:fs");
const path = require("node:path");

const TEST_DB = process.env.QUEUELESS_DB_PATH || path.join(__dirname, "..", "..", "_test.db");
process.env.QUEUELESS_DB_PATH = TEST_DB;
for (const suffix of ["", "-wal", "-shm"]) {
  if (fs.existsSync(TEST_DB + suffix)) fs.unlinkSync(TEST_DB + suffix);
}

const { initSchema } = require("../db/schema");
initSchema();

const Organization = require("./Organization");
const Service = require("./Service");
const Token = require("./Token");
const { estimateWait } = require("../utils/waitEstimator");

// 1. Create an organization + service
const org = Organization.create({ name: "City Clinic", category: "hospital", createdBy: null });
assert.ok(org.id, "organization should get an id");
assert.strictEqual(org.is_suspended, 0);

const service = Service.create({ organizationId: org.id, name: "General Consultation", avgServiceTimeMinutes: 7 });
assert.strictEqual(service.avg_service_time_minutes, 7);
console.log("PASS: created organization + service");

// 2. Joining the queue issues sequential token numbers starting at 1
const t1 = Token.joinQueue({ serviceId: service.id, guestName: "Alice" });
const t2 = Token.joinQueue({ serviceId: service.id, guestName: "Bob" });
const t3 = Token.joinQueue({ serviceId: service.id, guestName: "Carol" });
assert.strictEqual(t1.token_number, 1);
assert.strictEqual(t2.token_number, 2);
assert.strictEqual(t3.token_number, 3);
assert.strictEqual(t1.status, "waiting");
console.log("PASS: sequential token numbering");

// 3. Position / people-ahead is computed correctly
assert.strictEqual(Token.peopleAheadOf(t1), 0);
assert.strictEqual(Token.peopleAheadOf(t2), 1);
assert.strictEqual(Token.peopleAheadOf(t3), 2);
console.log("PASS: peopleAheadOf reflects queue order");

// 4. Calling next serves the earliest waiting token (Alice)
const serving1 = Token.callNext(service.id);
assert.strictEqual(serving1.id, t1.id);
assert.strictEqual(serving1.status, "serving");
assert.strictEqual(Token.getCurrentServing(service.id).id, t1.id);
// Bob and Carol move up: Bob now has 0 people ahead, Carol has 1
assert.strictEqual(Token.peopleAheadOf(Token.getById(t2.id)), 0);
assert.strictEqual(Token.peopleAheadOf(Token.getById(t3.id)), 1);
console.log("PASS: call-next serves earliest token and re-ranks the rest");

// 5. Calling next again auto-completes Alice and serves Bob
const serving2 = Token.callNext(service.id);
assert.strictEqual(serving2.id, t2.id);
const alice = Token.getById(t1.id);
assert.strictEqual(alice.status, "completed");
assert.ok(alice.actual_duration_minutes !== null, "completed token should record an actual duration");
console.log("PASS: calling next auto-completes whoever was being served");

// 6. Cancelling only works while still waiting
const cancelled = Token.cancel(t3.id);
assert.strictEqual(cancelled.status, "cancelled");
assert.strictEqual(Token.cancel(t3.id), null, "cancelling an already-cancelled token should fail");
console.log("PASS: cancel only succeeds for a waiting token");

// 7. Skip works on the currently-serving token
const skipped = Token.skip(t2.id);
assert.strictEqual(skipped.status, "skipped");
assert.strictEqual(Token.getCurrentServing(service.id), undefined);
console.log("PASS: skip clears the currently-serving slot");

// 8. Wait estimation integrates real historical durations from the DB
const service2 = Service.create({ organizationId: org.id, name: "Dental", avgServiceTimeMinutes: 10 });
const durations = [8, 9, 7, 8, 9];
const historyTokens = durations.map((_min, i) => Token.joinQueue({ serviceId: service2.id, guestName: `H${i}` }));
for (let i = 0; i < historyTokens.length; i++) {
  Token.callNext(service2.id); // serves historyTokens[i]
}
// force one more call-next to auto-complete the last one, using a manufactured duration via direct DB update is
// overkill here — instead just check that recent durations exist and are non-negative.
const recent = Token.getRecentDurations(service2.id, 10);
assert.ok(recent.length >= historyTokens.length - 1, "should have recorded completed durations");
assert.ok(recent.every((d) => d >= 0));

const newComer = Token.joinQueue({ serviceId: service2.id, guestName: "NewPerson" });
const estimate = estimateWait({
  peopleAhead: Token.peopleAheadOf(newComer),
  avgServiceTimeMinutes: service2.avg_service_time_minutes,
  recentDurationsMinutes: Token.getRecentDurations(service2.id, 10),
});
assert.strictEqual(typeof estimate.estimatedWaitMinutes, "number");
console.log(`PASS: end-to-end wait estimate for a fresh joiner = ${estimate.estimatedWaitMinutes} min (peopleAhead=${Token.peopleAheadOf(newComer)})`);

// 9. Daily token counter resets per service, not globally
const otherService = Service.create({ organizationId: org.id, name: "Pharmacy", avgServiceTimeMinutes: 3 });
const firstOfOther = Token.joinQueue({ serviceId: otherService.id, guestName: "X" });
assert.strictEqual(firstOfOther.token_number, 1, "a different service should start its own numbering at 1");
console.log("PASS: token numbering is scoped per service");

// 10. Organization suspension
const suspended = Organization.setSuspendedStatus(org.id, true);
assert.strictEqual(suspended.is_suspended, 1);
assert.strictEqual(Organization.listPublic().find((o) => o.id === org.id), undefined, "suspended org should not appear in public listing");
console.log("PASS: suspending an organization hides it from public listings");

console.log("\nAll model integration tests passed.");

// cleanup
for (const suffix of ["", "-wal", "-shm"]) {
  if (fs.existsSync(TEST_DB + suffix)) fs.unlinkSync(TEST_DB + suffix);
}
