const db = require("../db/connection");

const insertOrg = db.prepare(`
  INSERT INTO organizations (name, category, description, created_by)
  VALUES (@name, @category, @description, @created_by)
`);
const findById = db.prepare(`SELECT * FROM organizations WHERE id = ?`);
const listActive = db.prepare(`SELECT * FROM organizations WHERE is_suspended = 0 ORDER BY name ASC`);
const listAll = db.prepare(`SELECT * FROM organizations ORDER BY created_at DESC`);
const setSuspended = db.prepare(`UPDATE organizations SET is_suspended = ? WHERE id = ?`);

function create({ name, category, description = "", createdBy }) {
  const info = insertOrg.run({ name, category, description, created_by: createdBy });
  return findById.get(info.lastInsertRowid);
}

function getById(id) {
  return findById.get(id);
}

function listPublic() {
  return listActive.all();
}

function listForAdmin() {
  return listAll.all();
}

function setSuspendedStatus(id, suspended) {
  setSuspended.run(suspended ? 1 : 0, id);
  return findById.get(id);
}

module.exports = { create, getById, listPublic, listForAdmin, setSuspendedStatus };
