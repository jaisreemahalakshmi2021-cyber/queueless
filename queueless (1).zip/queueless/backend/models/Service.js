const db = require("../db/connection");
const { todayKey } = require("../utils/dateKey");

const insertService = db.prepare(`
  INSERT INTO services (organization_id, name, avg_service_time_minutes)
  VALUES (@organization_id, @name, @avg_service_time_minutes)
`);
const findById = db.prepare(`SELECT * FROM services WHERE id = ?`);
const listByOrg = db.prepare(`SELECT * FROM services WHERE organization_id = ? ORDER BY name ASC`);
const updateSettings = db.prepare(`
  UPDATE services SET avg_service_time_minutes = @avg_service_time_minutes, is_open = @is_open WHERE id = @id
`);
const bumpTokenCounter = db.prepare(`
  UPDATE services SET last_token_date = @today, last_token_number = @next WHERE id = @id
`);

function create({ organizationId, name, avgServiceTimeMinutes = 7 }) {
  const info = insertService.run({
    organization_id: organizationId,
    name,
    avg_service_time_minutes: avgServiceTimeMinutes,
  });
  return findById.get(info.lastInsertRowid);
}

function getById(id) {
  return findById.get(id);
}

function listByOrganization(organizationId) {
  return listByOrg.all(organizationId);
}

function updateService(id, { avgServiceTimeMinutes, isOpen }) {
  const current = findById.get(id);
  if (!current) return null;
  updateSettings.run({
    id,
    avg_service_time_minutes: avgServiceTimeMinutes ?? current.avg_service_time_minutes,
    is_open: isOpen === undefined ? current.is_open : (isOpen ? 1 : 0),
  });
  return findById.get(id);
}

/**
 * Atomically issues the next token number for a service, resetting the
 * counter to 1 whenever the calendar day changes (mirrors real token
 * machines at clinics/banks that reset every morning).
 * Returns { tokenNumber, tokenDate }.
 */
const issueTokenTxn = db.transaction((serviceId) => {
  const service = findById.get(serviceId);
  if (!service) throw new Error("Service not found");
  const today = todayKey();
  const isNewDay = service.last_token_date !== today;
  const next = isNewDay ? 1 : service.last_token_number + 1;
  bumpTokenCounter.run({ today, next, id: serviceId });
  return { tokenNumber: next, tokenDate: today };
});

function issueNextTokenNumber(serviceId) {
  return issueTokenTxn(serviceId);
}

module.exports = {
  create,
  getById,
  listByOrganization,
  updateService,
  issueNextTokenNumber,
};
