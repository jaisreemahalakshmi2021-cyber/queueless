const db = require("../db/connection");
const { todayKey, parseSqliteUtc } = require("../utils/dateKey");
const Service = require("./Service");

const insertToken = db.prepare(`
  INSERT INTO tokens (service_id, user_id, guest_name, token_number, token_date, status)
  VALUES (@service_id, @user_id, @guest_name, @token_number, @token_date, 'waiting')
`);
const findById = db.prepare(`SELECT * FROM tokens WHERE id = ?`);

const waitingAheadCount = db.prepare(`
  SELECT COUNT(*) AS cnt FROM tokens
  WHERE service_id = ? AND token_date = ? AND status = 'waiting' AND id < ?
`);

const currentServing = db.prepare(`
  SELECT * FROM tokens WHERE service_id = ? AND token_date = ? AND status = 'serving'
  ORDER BY called_at DESC LIMIT 1
`);

const nextWaiting = db.prepare(`
  SELECT * FROM tokens WHERE service_id = ? AND token_date = ? AND status = 'waiting'
  ORDER BY id ASC LIMIT 1
`);

const recentCompletedDurations = db.prepare(`
  SELECT actual_duration_minutes FROM tokens
  WHERE service_id = ? AND status = 'completed' AND actual_duration_minutes IS NOT NULL
  ORDER BY completed_at DESC LIMIT ?
`);

const setServing = db.prepare(`UPDATE tokens SET status = 'serving', called_at = datetime('now') WHERE id = ?`);
const setCompleted = db.prepare(`
  UPDATE tokens SET status = 'completed', completed_at = datetime('now'), actual_duration_minutes = ? WHERE id = ?
`);
const setSkipped = db.prepare(`UPDATE tokens SET status = 'skipped', completed_at = datetime('now') WHERE id = ?`);
const setCancelled = db.prepare(`UPDATE tokens SET status = 'cancelled' WHERE id = ? AND status = 'waiting'`);

const todayForService = db.prepare(`
  SELECT * FROM tokens WHERE service_id = ? AND token_date = ? ORDER BY id ASC
`);

const upcomingWaiting = db.prepare(`
  SELECT token_number FROM tokens WHERE service_id = ? AND token_date = ? AND status = 'waiting'
  ORDER BY id ASC LIMIT ?
`);

const historyForUser = db.prepare(`
  SELECT tokens.*, services.name AS service_name, organizations.name AS organization_name
  FROM tokens
  JOIN services ON services.id = tokens.service_id
  JOIN organizations ON organizations.id = services.organization_id
  WHERE tokens.user_id = ?
  ORDER BY tokens.joined_at DESC
`);

function joinQueue({ serviceId, userId = null, guestName = null }) {
  const { tokenNumber, tokenDate } = Service.issueNextTokenNumber(serviceId);
  const info = insertToken.run({
    service_id: serviceId,
    user_id: userId,
    guest_name: guestName,
    token_number: tokenNumber,
    token_date: tokenDate,
  });
  return findById.get(info.lastInsertRowid);
}

function getById(id) {
  return findById.get(id);
}

/** People still WAITING ahead of this token (does not include whoever is currently being served). */
function peopleAheadOf(token) {
  const row = waitingAheadCount.get(token.service_id, token.token_date, token.id);
  return row.cnt;
}

function getCurrentServing(serviceId, tokenDate = todayKey()) {
  return currentServing.get(serviceId, tokenDate);
}

function getRecentDurations(serviceId, limit = 10) {
  return recentCompletedDurations.all(serviceId, limit).map((r) => r.actual_duration_minutes);
}

/**
 * Calls the next customer for a service. If someone is already being
 * served, they are auto-marked completed first (their actual duration is
 * recorded for the historical average) so the queue never has two people
 * "serving" at once.
 */
const callNextTxn = db.transaction((serviceId) => {
  const today = todayKey();
  const serving = currentServing.get(serviceId, today);
  if (serving) {
    completeInternal(serving);
  }
  const next = nextWaiting.get(serviceId, today);
  if (!next) return null;
  setServing.run(next.id);
  return findById.get(next.id);
});

function completeInternal(token) {
  const calledAt = token.called_at ? parseSqliteUtc(token.called_at) : null;
  const now = new Date();
  const durationMinutes = calledAt ? Math.max(0.1, (now - calledAt) / 60000) : null;
  setCompleted.run(durationMinutes, token.id);
}

function callNext(serviceId) {
  return callNextTxn(serviceId);
}

function completeCurrent(tokenId) {
  const token = findById.get(tokenId);
  if (!token || token.status !== "serving") return null;
  completeInternal(token);
  return findById.get(tokenId);
}

function skip(tokenId) {
  const token = findById.get(tokenId);
  if (!token || (token.status !== "serving" && token.status !== "waiting")) return null;
  setSkipped.run(tokenId);
  return findById.get(tokenId);
}

function cancel(tokenId) {
  const result = setCancelled.run(tokenId);
  if (result.changes === 0) return null;
  return findById.get(tokenId);
}

function listToday(serviceId, tokenDate = todayKey()) {
  return todayForService.all(serviceId, tokenDate);
}

function upcomingTokenNumbers(serviceId, limit = 3, tokenDate = todayKey()) {
  return upcomingWaiting.all(serviceId, tokenDate, limit).map((r) => r.token_number);
}

function historyFor(userId) {
  return historyForUser.all(userId);
}

module.exports = {
  joinQueue,
  getById,
  peopleAheadOf,
  getCurrentServing,
  getRecentDurations,
  callNext,
  completeCurrent,
  skip,
  cancel,
  listToday,
  upcomingTokenNumbers,
  historyFor,
};
