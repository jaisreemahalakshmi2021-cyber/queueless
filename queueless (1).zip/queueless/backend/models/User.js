const db = require("../db/connection");

const insertUser = db.prepare(`
  INSERT INTO users (name, email, password_hash, role, organization_id)
  VALUES (@name, @email, @password_hash, @role, @organization_id)
`);

const findByEmail = db.prepare(`SELECT * FROM users WHERE email = ?`);
const findById = db.prepare(`SELECT * FROM users WHERE id = ?`);
const setOrganization = db.prepare(`UPDATE users SET organization_id = ? WHERE id = ?`);
const allUsers = db.prepare(`SELECT id, name, email, role, organization_id, created_at FROM users ORDER BY created_at DESC`);

function create({ name, email, passwordHash, role, organizationId = null }) {
  const info = insertUser.run({
    name,
    email,
    password_hash: passwordHash,
    role,
    organization_id: organizationId,
  });
  return findById.get(info.lastInsertRowid);
}

function getByEmail(email) {
  return findByEmail.get(email);
}

function getById(id) {
  return findById.get(id);
}

function attachOrganization(userId, organizationId) {
  setOrganization.run(organizationId, userId);
}

function list() {
  return allUsers.all();
}

function toSafeJSON(user) {
  if (!user) return null;
  const { password_hash, ...safe } = user;
  return safe;
}

module.exports = { create, getByEmail, getById, attachOrganization, list, toSafeJSON };
