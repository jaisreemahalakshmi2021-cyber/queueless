const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "queueless-dev-secret-change-me";
const JWT_EXPIRES_IN = "12h";

function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, organizationId: user.organization_id, name: user.name, email: user.email },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

/** Populates req.user if a valid Bearer token is present; never rejects by itself. */
function optionalAuth(req, _res, next) {
  const header = req.headers.authorization;
  if (header && header.startsWith("Bearer ")) {
    try {
      req.user = jwt.verify(header.slice(7), JWT_SECRET);
    } catch (_err) {
      // ignore invalid/expired token — treat as anonymous
    }
  }
  next();
}

/** Requires a valid Bearer token. */
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Authentication required" });
  }
  try {
    req.user = jwt.verify(header.slice(7), JWT_SECRET);
    next();
  } catch (_err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

/** Requires the authenticated user to have one of the given roles. */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "You don't have permission to do that" });
    }
    next();
  };
}

module.exports = { signToken, optionalAuth, requireAuth, requireRole, JWT_SECRET };
