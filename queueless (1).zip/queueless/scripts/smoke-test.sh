#!/usr/bin/env bash
# Quick end-to-end smoke test against a running QueueLess server.
#
# Usage:
#   1. In one terminal:  npm run seed && npm start
#   2. In another:       bash scripts/smoke-test.sh
#
# Exercises the main flow end-to-end: log in as a demo org admin, join a
# queue as a guest, check the position/estimate, call next, and confirm
# the token is now "serving". Requires `curl` and `jq`.
set -euo pipefail
BASE="http://localhost:${PORT:-4000}"

if ! command -v jq >/dev/null 2>&1; then
  echo "This script needs 'jq' installed (e.g. apt install jq / brew install jq)." >&2
  exit 1
fi

echo "1) Health check..."
curl -sf "$BASE/api/health" | jq .

echo -e "\n2) Log in as the demo City Clinic admin..."
LOGIN=$(curl -sf -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" \
  -d '{"email":"admin@cityclinic.demo","password":"password123"}')
TOKEN_JWT=$(echo "$LOGIN" | jq -r .token)
ORG_ID=$(echo "$LOGIN" | jq -r .user.organization_id)
echo "   Logged in, organization_id=$ORG_ID"

echo -e "\n3) List that organization's services..."
SERVICES=$(curl -sf "$BASE/api/organizations/$ORG_ID/services")
SERVICE_ID=$(echo "$SERVICES" | jq -r '.services[0].id')
echo "   Using service_id=$SERVICE_ID ($(echo "$SERVICES" | jq -r '.services[0].name'))"

echo -e "\n4) Join the queue as a guest (simulating a QR scan)..."
JOIN=$(curl -sf -X POST "$BASE/api/services/$SERVICE_ID/join" -H "Content-Type: application/json" \
  -d '{"guestName":"Smoke Test Guest"}')
TOKEN_ID=$(echo "$JOIN" | jq -r .token.id)
TOKEN_NUMBER=$(echo "$JOIN" | jq -r .token.token_number)
echo "   Got token #$TOKEN_NUMBER (id=$TOKEN_ID)"

echo -e "\n5) Check position + estimated wait..."
curl -sf "$BASE/api/tokens/$TOKEN_ID" | jq '{status: .token.status, peopleAhead, estimatedWaitMinutes}'

echo -e "\n6) Call next as the org admin..."
CALLED=$(curl -sf -X POST "$BASE/api/services/$SERVICE_ID/call-next" -H "Authorization: Bearer $TOKEN_JWT")
echo "$CALLED" | jq .

echo -e "\n7) Confirm the token is now being served (or was completed if others were ahead)..."
curl -sf "$BASE/api/tokens/$TOKEN_ID" | jq '{status: .token.status}'

echo -e "\nSmoke test finished. If every step above printed JSON without errors, the app is working end to end."
